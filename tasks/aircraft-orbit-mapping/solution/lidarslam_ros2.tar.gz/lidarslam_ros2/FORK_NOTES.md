# Provenance of this vendored copy

Upstream: https://github.com/rsasaki0109/lidarslam_ros2 (BSD-2-Clause, Ryohei Sasaki), vendored at
upstream commit 6213770d (2024-05-28) with the bundled `Thirdparty/ndt_omp_ros2` (BSD-2-Clause,
k.koide; byte-identical to the upstream submodule at that commit).

Local modifications relative to that commit, made by the robot platform's engineering team for bag replay on a
multi-LiDAR ground robot and reused here with permission (all still BSD-2-Clause):

1. `scanmatcher/src/scanmatcher_component.cpp`
   - subscribe to `input_cloud` with `rclcpp::SensorDataQoS()` (best-effort, matches sensor
     drivers and `ros2 bag play`);
   - odom prior: if the exact-stamp `odom -> base_link` TF lookup fails (typically a ~1 ms
     extrapolation gap because the 10 Hz odom lags the scan stamp), fall back to the latest
     available transform (`tf2::TimePointZero`); if that also fails, skip the odom update for
     this scan instead of feeding an identity prior into NDT.
2. `lidarslam/param/lidarslam.yaml`
   - `publish_tf: true`, `odom_frame_id: "odom"`, `use_odom: true`;
   - `ndt_resolution: 1.0` (was 2.0), `ndt_num_threads: 4`, `vg_size_for_map: 0.2` (was 0.1),
     `scan_max_range: 100.0` (was 200.0); graph back-end `voxel_leaf_size: 0.2` (was 0.1).
3. `lidarslam/launch/lidarslam.launch.py`
   - `use_sim_time` launch argument passed to every node; `/input_cloud` remapped to
     `/fused_points`; the static `base_link -> velodyne` publisher replaced by a (commented out)
     `base_link -> hesai` one. The task's oracle uses its own launch file (`solution/slam.launch.py`)
     and parameter file (`solution/lidarslam_params.yaml`), so this file is informational only.

No other source files differ from upstream at that commit.
