# lidar_slam_ros2 Installation Guide

## Installation Dependencies and Setup

### Step 1: Install Dependencies

1. **Update your package list:**
    ```bash
    sudo apt-get update
    ```

2. **Install the necessary dependencies:**
    ```bash
    sudo apt-get install -y cmake build-essential libeigen3-dev libsuitesparse-dev libboost-all-dev libpcl-dev ros-foxy-pcl-conversions
    ```

### Step 2: Install g2o from Source

1. **Clone the g2o repository from GitHub:**
    ```bash
    git clone https://github.com/RainerKuemmerle/g2o.git
    ```

2. **Navigate into the g2o directory:**
    ```bash
    cd g2o
    ```

3. **Create a new directory called `build` inside the g2o directory and navigate into it:**
    ```bash
    mkdir build
    cd build
    ```

4. **Configure the build using CMake:**
    ```bash
    cmake ..
    ```

5. **Compile the source code:**
    ```bash
    make -j$(nproc)
    ```

6. **Install the g2o library:**
    ```bash
    sudo make install
    ```

### Step 3: Set Environment Variables

1. **Add `/usr/local/lib` to your `LD_LIBRARY_PATH` environment variable temporarily:**
    ```bash
    export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/usr/local/lib
    ```

2. **To make this change permanent, add the export command to your `.bashrc` or `.zshrc` file:**
    ```bash
    echo 'export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/usr/local/lib' >> ~/.bashrc
    source ~/.bashrc
    ```

### Step 4: Clone and Build lidar_slam_ros2

1. **Create a ROS 2 workspace if you don't already have one:**
    ```bash
    mkdir -p ~/ros2_ws/src
    cd ~/ros2_ws/src
    ```

2. **Clone the `lidar_slam_ros2` repository:**
    ```bash
    git clone https://github.com/your_repo/lidar_slam_ros2.git
    ```

3. **Navigate into the `lidar_slam_ros2` directory:**
    ```bash
    cd lidar_slam_ros2
    ```

4. **Clone any other required repositories into the `src` directory of your workspace.**

5. **Go back to the root of your workspace:**
    ```bash
    cd ~/ros2_ws
    ```

6. **Build the workspace:**
    ```bash
    colcon build
    ```

### Step 5: Source Your Workspace

After building your workspace, source the setup script to overlay this workspace on top of your current ROS 2 environment:

```bash
source ~/ros2_ws/install/setup.bash
```

### Step 6: Run the Package
To run the lidar_slam_ros2 package, use the appropriate launch file. If you encounter errors related to libg2o_types_slam3d.so.0.1, ensure that your LD_LIBRARY_PATH is correctly set (refer to Step 3).

```ros2 launch lidarslam lidarslam.launch.py
```

## Fix CMake Error for Eigen

If you encounter CMake errors related to Eigen, follow these steps:

1. **Verify that Eigen3 is installed and located in `/usr/include/eigen3`.**

2. **If not, create a symlink:**
    ```bash
    sudo ln -s /usr/include/eigen3 /opt/ros/humble/include/eigen3
    ```

3. **Modify the `CMakeLists.txt` of the affected package to include Eigen3:**

    ```cmake
    # Set the path to Eigen3
    set(Eigen3_INCLUDE_DIR /usr/include/eigen3)
    include_directories(${Eigen3_INCLUDE_DIR})

    # Find package dependencies
    find_package(PCL REQUIRED)
    find_package(Eigen3 REQUIRED)
    find_package(roscpp REQUIRED)
    find_package(sensor_msgs REQUIRED)

    include_directories(${PCL_INCLUDE_DIRS} ${Eigen3_INCLUDE_DIR} ${roscpp_INCLUDE_DIRS})

    # Your executable target
    add_executable(your_executable_name src/your_source_file.cpp)
    target_link_libraries(your_executable_name ${PCL_LIBRARIES} ${roscpp_LIBRARIES})
    ```

4. **Clean and rebuild your workspace:**
    ```bash
    colcon build --clean
    colcon build
    ```
