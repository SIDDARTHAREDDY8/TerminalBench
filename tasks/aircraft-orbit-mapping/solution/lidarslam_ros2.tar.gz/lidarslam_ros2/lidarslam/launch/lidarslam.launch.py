import os

import launch
import launch_ros.actions

from ament_index_python.packages import get_package_share_directory

def generate_launch_description():

    main_param_dir = launch.substitutions.LaunchConfiguration(
        'main_param_dir',
        default=os.path.join(
            get_package_share_directory('lidarslam'),
            'param',
            'lidarslam.yaml'))

    rviz_param_dir = launch.substitutions.LaunchConfiguration(
        'rviz_param_dir',
        default=os.path.join(
            get_package_share_directory('lidarslam'),
            'rviz',
            'mapping.rviz'))

    use_sim_time = launch.substitutions.LaunchConfiguration('use_sim_time')

    mapping = launch_ros.actions.Node(
        package='scanmatcher',
        executable='scanmatcher_node',
        parameters=[main_param_dir, {'use_sim_time': use_sim_time}],
        remappings=[('/input_cloud','/fused_points'), ('/imu','/fixposition/poiimu')],
        output='screen'
        )

    #commented out below
    tf = launch_ros.actions.Node(
        package='tf2_ros',
        executable='static_transform_publisher',
        arguments=['-0.010', '0.000', '1.127', '0.000', '-0.000', '0.000', '1', 'base_link', 'hesai'],
        parameters=[{'use_sim_time': use_sim_time}]
        )


    graphbasedslam = launch_ros.actions.Node(
        package='graph_based_slam',
        executable='graph_based_slam_node',
        parameters=[main_param_dir, {'use_sim_time': use_sim_time}],
        output='screen'
        )

    rviz = launch_ros.actions.Node(
        package='rviz2',
        executable='rviz2',
        arguments=['-d', rviz_param_dir],
        parameters=[{'use_sim_time': use_sim_time}]
        )


    return launch.LaunchDescription([
        launch.actions.DeclareLaunchArgument(
            'main_param_dir',
            default_value=main_param_dir,
            description='Full path to main parameter file to load'),
        launch.actions.DeclareLaunchArgument(
            'use_sim_time',
            default_value='false',
            description='Use simulation time from /clock topic'),
        mapping,
        # tf,
        graphbasedslam,
        rviz,
            ])